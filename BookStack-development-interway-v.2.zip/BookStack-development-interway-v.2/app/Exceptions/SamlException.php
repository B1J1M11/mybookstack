<?php

namespace BookStack\Exceptions;

class SamlException extends NotifyException
{
}
