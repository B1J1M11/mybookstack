<?php

namespace BookStack\Exceptions;

class ThemeException extends \Exception
{
}
