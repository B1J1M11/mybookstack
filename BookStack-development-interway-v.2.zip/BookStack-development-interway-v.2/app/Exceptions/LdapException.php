<?php

namespace BookStack\Exceptions;

class LdapException extends PrettyException
{
}
